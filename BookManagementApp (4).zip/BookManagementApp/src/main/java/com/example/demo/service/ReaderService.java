package com.example.demo.service;

import java.util.Set;

import com.example.demo.model.Reader;

public interface ReaderService 
{
	public Set<Reader> getAllReaders(int bookId);
	public boolean addReader(Reader reader);
	public boolean deleteReader(int bookId);

}
