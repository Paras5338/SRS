package com.example.demo.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Reader 
{
	@Id
	@GeneratedValue
	private int transactionId;
	
	private String readerName;
	
	private Date issueAt;
	
	private int book_id_fk;

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getReaderName() {
		return readerName;
	}

	public void setReaderName(String readerName) {
		this.readerName = readerName;
	}

	public Date getIssueAt() {
		return issueAt;
	}

	public void setIssueAt(Date issueAt) {
		this.issueAt = issueAt;
	}

	public int getBook_id_fk() {
		return book_id_fk;
	}

	public void setBook_id_fk(int book_id_fk) {
		this.book_id_fk = book_id_fk;
	}
	
	
	
	
	

}
