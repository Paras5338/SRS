package com.example.demo.controller;

import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exceptions.BookIdAlreadyExistsExceptions;
import com.example.demo.model.Book;
import com.example.demo.model.Reader;
import com.example.demo.response.ResponseHandler;
import com.example.demo.service.BookService;
import com.example.demo.service.ReaderService;

import io.swagger.v3.oas.annotations.Hidden;

@RestController
@RequestMapping("api/v1")
public class BookController
{
	@Autowired
	private BookService bookService;
	
	@Autowired
	private ReaderService rs;
	
	@GetMapping("/getAllBooks")
	public ResponseEntity<?> getAllBooks()
	{
		List<Book> booklist = bookService.getAllBooks();
		
		if(booklist !=null)
		{
			//return new ResponseEntity<List<Book>>(booklist, HttpStatus.OK);
			
		//return ResponseHandler.generateResponse("Succesfully fetched the booklist", HttpStatus.OK, booklist);
			
			for(Book b :booklist)
			{
				Set<Reader> readerlist = rs.getAllReaders(b.getBookId());
				b.setReaderList(readerlist);
			}
			
			CacheControl cacheControlObj = CacheControl.maxAge(30, TimeUnit.MINUTES);
			return ResponseEntity.ok().cacheControl(cacheControlObj)
					.body(ResponseHandler.generateResponse("Succesfully fetched the booklist", HttpStatus.OK, booklist));
		}
		return new ResponseEntity<String>("booklist is empty", HttpStatus.NO_CONTENT);
		
	}
	
	@PostMapping("/addBook")
	public ResponseEntity<?> addBook(@RequestBody Book book) throws BookIdAlreadyExistsExceptions
	{
		if(bookService.addBook(book)!=null)
		{
			return new ResponseEntity<Book>(book, HttpStatus.CREATED);
		}
		
		return new ResponseEntity<String>("book object is null", HttpStatus.NO_CONTENT);
	}
	
	@DeleteMapping("/delete/{bid}")
	public ResponseEntity<?> deleteBook(@PathVariable ("bid") int bid)
	{
		if(bookService.deleteBook(bid))
		{
			return new ResponseEntity<String>("Book got deleted successfully",HttpStatus.OK);
		}
		
		return new ResponseEntity<String>("Book did not get deleted ",HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@Hidden
	@PutMapping("/updateBook")
	public ResponseEntity<?> updateBook(@RequestBody Book book)
	{
		if(bookService.updateBook(book))
		{
			return new ResponseEntity<String>("Book got updated successfully",HttpStatus.OK);
		}
		
		return new ResponseEntity<String>("Book updation failed",HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@GetMapping("/bookById/{bid}")
	public ResponseEntity<?> getBookById(@PathVariable("bid") int bid)
	{
		Book bookexists = bookService.getBookById(bid);
		if(bookexists !=null)
		{
			
			Set<Reader> readerlist = rs.getAllReaders(bookexists.getBookId());
			bookexists.setReaderList(readerlist);
			return new ResponseEntity<Book>(bookexists, HttpStatus.OK);
		}
		return new ResponseEntity<String>("Book record does not exist",HttpStatus.NO_CONTENT);
	}
	

}






