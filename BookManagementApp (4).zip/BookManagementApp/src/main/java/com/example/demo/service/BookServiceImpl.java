package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exceptions.BookIdAlreadyExistsExceptions;
import com.example.demo.model.Book;
import com.example.demo.repository.BookRepository;

@Service
public class BookServiceImpl implements BookService
{
	@Autowired
	private BookRepository bookRepo;
	

	@Override
	public List<Book> getAllBooks()
	{
		List<Book> booklist = bookRepo.findAll();
		if(booklist !=null && booklist.size()> 0)
		{
			return booklist;
		}
		else
			return null;
		
	}

	@Override
	public Book addBook(Book book) throws BookIdAlreadyExistsExceptions
	{
		Optional<Book> opBook = bookRepo.findById(book.getBookId());
		if(opBook.isPresent())
		{
			throw new BookIdAlreadyExistsExceptions();
		}
		else
			return bookRepo.saveAndFlush(book);
	}

	@Override
	public boolean updateBook(Book book) {
		Book book1 = bookRepo.getById(book.getBookId());
		
		if(book1 !=null)
		{
			book1.setBookPrice(book.getBookPrice());
			bookRepo.saveAndFlush(book1);
			return true;
		}
		return false;
		
	}

	@Override
	public boolean deleteBook(int bid) {
		bookRepo.deleteById(bid);
		return true;
	}

	@Override
	public Book getBookById(int bid) {
		
		Optional <Book> book = bookRepo.findById(bid);
		if(book.isPresent())
		{
			return book.get();
		}
		return null;
	}

}
