package com.example.demo.model;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Book 
{
	@Id
	private int bookId;
	private String bookName;
	private double bookPrice;
	private String readerName;
	
	@OneToMany(targetEntity= Reader.class)
	public Set<Reader> readerList;
	
	
	
	public String getReaderName() {
		return readerName;
	}
	public void setReaderName(String readerName) {
		this.readerName = readerName;
	}
	public Set<Reader> getReaderList() {
		return readerList;
	}
	public void setReaderList(Set<Reader> readerList) {
		this.readerList = readerList;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public double getBookPrice() {
		return bookPrice;
	}
	public void setBookPrice(double bookPrice) {
		this.bookPrice = bookPrice;
	}
	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookName=" + bookName + ", bookPrice=" + bookPrice + ", readerName="
				+ readerName + ", readerList=" + readerList + "]";
	}
	
	

}
