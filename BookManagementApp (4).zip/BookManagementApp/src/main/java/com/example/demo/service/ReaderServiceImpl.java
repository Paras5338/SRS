package com.example.demo.service;

import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Reader;
import com.example.demo.repository.ReaderRepository;

@Service
public class ReaderServiceImpl implements ReaderService{
	@Autowired
	private ReaderRepository readerRepo;

	@Override
	public Set<Reader> getAllReaders(int bookId) {
		
		Set<Reader> readerlist = readerRepo.getReaderList(bookId);
		return readerlist;
	}

	@Override
	public boolean addReader(Reader reader) {
		
		
			Reader readerObj = new Reader();
			readerObj.setReaderName(reader.getReaderName());
			readerObj.setIssueAt(reader.getIssueAt());
			readerObj.setBook_id_fk(reader.getBook_id_fk());
			readerRepo.saveAndFlush(readerObj);
			return true;
			
		}
		/*Optional<Reader> rObj = readerRepo.findById(reader.getBook_id_fk());
		if(rObj.isPresent())
		{

			readerRepo.saveAndFlush(reader);
			return true;
		}
		return false;*/
	

	@Override
	public boolean deleteReader(int bookId) {
		readerRepo.deleteReaderData(bookId);
		return true;
	}

}
