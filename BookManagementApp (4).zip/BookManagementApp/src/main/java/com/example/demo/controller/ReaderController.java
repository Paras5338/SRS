package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Book;
import com.example.demo.model.Reader;
import com.example.demo.service.BookService;
import com.example.demo.service.ReaderService;

@RestController
@RequestMapping("api/v1/reader")
public class ReaderController 
{
	@Autowired
	private ReaderService rs;
	
	@Autowired
	private BookService bs;
	
	
	@PostMapping("/add/{bid}")    // @RequestParam
	public ResponseEntity<?> addReader(@PathVariable("bid") int bid, @RequestBody Reader reader)
	{
		Book bookexists = bs.getBookById(bid);
		if(bookexists!=null)
		{
			bookexists.setReaderName(reader.getReaderName());//reader name is updated in ReaderName column in  book table
			reader.setReaderName(reader.getReaderName());//reader name is added in Reader table
			reader.setBook_id_fk(reader.getBook_id_fk());
			reader.setIssueAt(reader.getIssueAt());
			
			if(bs.updateBook(bookexists) && rs.addReader(reader))
			{
				return new ResponseEntity<Reader>(reader, HttpStatus.CREATED);
			}
			
			
		}
		return new ResponseEntity<String>("Book reader name cannot be added", HttpStatus.INTERNAL_SERVER_ERROR);
		
	}
			
	

}
