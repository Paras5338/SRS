package com.example.demo.service;

import java.util.List;

import com.example.demo.exceptions.BookIdAlreadyExistsExceptions;
import com.example.demo.model.Book;

public interface BookService 
{

	public List<Book> getAllBooks();
	
	public Book addBook(Book book) throws BookIdAlreadyExistsExceptions;
	
	public boolean updateBook(Book book);
	
	public boolean deleteBook(int bid);
	
	public Book getBookById(int bid);
	
	
}
