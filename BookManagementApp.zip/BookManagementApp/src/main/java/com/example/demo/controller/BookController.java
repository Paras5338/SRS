package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exceptions.BookIdAlreadyExistsExceptions;
import com.example.demo.model.Book;
import com.example.demo.service.BookService;

@RestController
@RequestMapping("api/v1")
public class BookController
{
	@Autowired
	private BookService bookService;
	
	@GetMapping("/getAllBooks")
	public ResponseEntity<?> getAllBooks()
	{
		List<Book> booklist = bookService.getAllBooks();
		
		if(booklist !=null)
		{
			return new ResponseEntity<List<Book>>(booklist, HttpStatus.OK);
		}
		return new ResponseEntity<String>("booklist is empty", HttpStatus.NO_CONTENT);
		
	}
	
	@PostMapping("/addBook")
	public ResponseEntity<?> addBook(@RequestBody Book book) throws BookIdAlreadyExistsExceptions
	{
		if(bookService.addBook(book)!=null)
		{
			return new ResponseEntity<Book>(book, HttpStatus.CREATED);
		}
		
		return new ResponseEntity<String>("book object is null", HttpStatus.NO_CONTENT);
	}
	
	@DeleteMapping("/delete/{bid}")
	public ResponseEntity<?> deleteBook(@PathVariable ("bid") int bid)
	{
		if(bookService.deleteBook(bid))
		{
			return new ResponseEntity<String>("Book got deleted successfully",HttpStatus.OK);
		}
		
		return new ResponseEntity<String>("Book did not get deleted ",HttpStatus.INTERNAL_SERVER_ERROR);
	}

}






